rsync -avz clusman:/var/spool/moab/stats/* stats
