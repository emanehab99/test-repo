#!/usr/bin/env python

import stats
import sys

key='group'
if sys.argv[1] == '-a':
   key='account'
   sys.argv.remove('-a')
elif sys.argv[1] == '-u':
   key='user'
   sys.argv.remove('-u')
month=sys.argv[1]
year=sys.argv[2]

theJobs = stats.getJobs(['stats/*'+month+'*'+year])
print "%%%%%%%% Report for " + month + " " + year + " %%%%%%%%"
print


print "--- Summary"
groups = stats.Collect(theJobs,key,'JOBEND')
jobs=[(group,len(groups[group]),sum(groups[group])) for group in groups.keys()]
jobs.sort(key=lambda tup: tup[2])
for job in jobs:
  print "%-13s %5d jobs; %10.2f cpu-hours" % job
print "-----------------------------------------------"
print



queues = stats.Collect(theJobs,'queue','JOBEND')
for queue in sorted(queues.keys()):
  groups = stats.Collect(queues[queue],key)
  print "--- " + queue.upper()

  jobs=[(group,len(groups[group]),sum(groups[group])) for group in groups.keys()]
  jobs.sort(key=lambda tup: tup[2])
  for job in jobs:
    print "%-13s %5d jobs; %10.2f cpu-hours" % job
  print "-----------------------------------------------"
  print

