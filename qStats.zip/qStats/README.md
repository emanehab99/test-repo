# qStats
A set of pyhon utilities to analyze Moab queue stat files

stats.py defines the Job class and provides the Collect function to generate useful dictionaries.

the upper-case scripts import stats module, read a stats file and prints output from calls to Collect.
